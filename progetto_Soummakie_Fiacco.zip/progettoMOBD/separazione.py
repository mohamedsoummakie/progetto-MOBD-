from sklearn.datasets import load_svmlight_file, dump_svmlight_file
from sklearn.model_selection import train_test_split

# 1. CARICARE IL FILE TXT
# Questa funzione riconosce in automatico il formato "classe indice:valore"
# e separa già i dati (X) dalle classi (y)
X, y = load_svmlight_file('dataset.txt')

# 2. DIVISIONE 80% TRAINING / 10% VALIDATION / 10% TEST CON STRATIFICAZIONE
# Si procede in due passaggi, perche' train_test_split divide solo in due parti:
#   a) 80% training  vs  20% "resto" (che poi diventa val + test)
#   b) il 20% "resto" viene diviso a meta' -> 10% validation + 10% test
X_train, X_temp, y_train, y_temp = train_test_split(
    X,
    y,
    test_size=0.20,    # 20% va in "resto" (poi diviso in val/test)
    stratify=y,        # mantiene la proporzione delle classi
    random_state=42
)

X_val, X_test, y_val, y_test = train_test_split(
    X_temp,
    y_temp,
    test_size=0.50,    # meta' del 20% -> 10% validation, meta' -> 10% test
    stratify=y_temp,   # mantiene la proporzione delle classi anche qui
    random_state=42
)

# 3. SALVARE I RISULTATI IN NUOVI FILE TXT
# Salva i tre nuovi set mantenendo esattamente la formattazione originale
dump_svmlight_file(X_train, y_train, 'training_set.txt')
dump_svmlight_file(X_val, y_val, 'validation_set.txt')
dump_svmlight_file(X_test, y_test, 'test_set.txt')

print("Divisione completata con successo!")
print(f"Training set:   {X_train.shape[0]} campioni ({X_train.shape[0] / X.shape[0]:.1%})")
print(f"Validation set: {X_val.shape[0]} campioni ({X_val.shape[0] / X.shape[0]:.1%})")
print(f"Test set:       {X_test.shape[0]} campioni ({X_test.shape[0] / X.shape[0]:.1%})")
print("File salvati: training_set.txt, validation_set.txt, test_set.txt")