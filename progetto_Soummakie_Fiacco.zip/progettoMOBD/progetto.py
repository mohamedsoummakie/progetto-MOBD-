import time
import matplotlib.pyplot as plt
import numpy as np

RNG_SEED = 42

# ============================================================================
# 1. CARICAMENTO E PRE-PROCESSING DEI DATI
# ============================================================================
def load_libsvm_dataset(path):
    """Legge un file in formato 'label 0:v0 1:v1 2:v2' e restituisce
    X (n_samples, 3) float64 e y (n_samples,1) con 1=skin, 0=no-skin."""
    # X_rows conterrà le feature, y_rows conterrà le etichette
    X_rows, y_rows = [], []
    # Apre il file dato in input in modalità lettura
    with open(path, "r") as f:
        for line in f:
            # Rimuove eventuali spazi vuoti iniziali/finali
            line = line.strip()
            # Se la riga è vuota, salta e passa alla prossima riga
            if not line:
                continue
            # Spezza la riga in una lista di stringhe usando gli spazi come separatore
            parts = line.split()
            # Prende il primo elemento della lista (la classe) e lo converte in intero
            label = int(parts[0])
            # Per ogni frammento (es. 1:74), lo divide a metà usando i due punti come separatore,
            # seleziona la seconda parte, la converte in decimale e la aggiunge a feats
            feats = [float(p.split(":")[1]) for p in parts[1:]]
            # Aggiunge l'intera lista di valori alla lista principale delle feature
            X_rows.append(feats)
            # Aggiunge l'etichetta alla lista delle classi convertita in 1.0 o 0.0
            y_rows.append(1.0 if label == 1 else 0.0)  # 1=skin, 2->0=no-skin
    # I dati vengono convertiti in array numpy
    X = np.asarray(X_rows, dtype=np.float64)
    y = np.asarray(y_rows, dtype=np.float64).reshape(-1, 1)
    return X, y


class StandardScaler:
    """Standardizzazione (z-score) scritta a mano: fit SOLO sul training set."""
    
    def fit(self, X):
        # Calcola la media e la deviazione standard per ciascuna colonna (feature) 
        # utilizzando esclusivamente i dati del training set (X).
        
        # Calcola la media aritmetica in verticale per ogni colonna
        self.mean_ = X.mean(axis=0)
        
        # Calcola la deviazione standard in verticale per ogni colonna
        self.std_ = X.std(axis=0)
        
        # Controllo di sicurezza: se una colonna ha deviazione standard pari a 0 
        # (es. tutti valori uguali), la imposta a 1.0 per evitare divisioni per zero
        self.std_[self.std_ == 0] = 1.0
        
        # Restituisce l'oggetto stesso per permettere la concatenazione dei comandi
        return self

    def transform(self, X):
        # Applica la trasformazione z-score ai dati (X) utilizzando 
        # la media e la deviazione standard precedentemente calcolate nel fit.
        # Formula: (valore - media) / deviazione_standard
        return (X - self.mean_) / self.std_

    def fit_transform(self, X):
        # Metodo di comodità che esegue prima il calcolo dei parametri (fit) 
        # e subito dopo applica la trasformazione (transform) sullo stesso dataset.
        return self.fit(X).transform(X)

# ============================================================================
# 2. FUNZIONI DI ATTIVAZIONE
# ============================================================================
def relu(z):
    return np.maximum(0, z)


def relu_derivative(z):
    return (z > 0).astype(z.dtype)


def sigmoid(z):
    z = np.clip(z, -500, 500)  # stabilità numerica per evitare overflow di exp
    return 1.0 / (1.0 + np.exp(-z))


# =================
# 3. RETE NEURALE 
# =================
class NeuralNetwork:
    """
    MLP: Input(3) -> Dense(hidden1, ReLU) -> Dense(hidden2, ReLU) -> Dense(1, Sigmoid)
    - Init pesi: He (strati ReLU) / Xavier (output sigmoid)
    - Ottimizzatore: Adam implementato a mano
    - Loss: Binary Cross-Entropy pesata (sbilanciamento classi) + L2
    """

    def __init__(self, layer_sizes, l2_lambda=1e-4, seed=None):
        self.layer_sizes = layer_sizes
        self.L = len(layer_sizes) - 1  # Numero di strati della rete (escluso l'input)
        self.l2_lambda = l2_lambda
        rng = np.random.default_rng(seed)

        # Inizializzazione dei pesi (W) e dei bias (b) per ciascun layer
        self.W, self.b = {}, {}
        for l in range(1, self.L + 1):
            fan_in, fan_out = layer_sizes[l - 1], layer_sizes[l]
            # He initialization per gli strati nascosti, Xavier per l'ultimo strato
            scale = np.sqrt(2.0 / fan_in) if l < self.L else np.sqrt(1.0 / fan_in)
            self.W[l] = rng.normal(0, scale, size=(fan_in, fan_out))
            self.b[l] = np.zeros((1, fan_out))

        # Inizializzazione dello stato dell'ottimizzatore Adam (momenti m e v a zero)
        self._m_W = {l: np.zeros_like(self.W[l]) for l in self.W}
        self._v_W = {l: np.zeros_like(self.W[l]) for l in self.W}
        self._m_b = {l: np.zeros_like(self.b[l]) for l in self.b}
        self._v_b = {l: np.zeros_like(self.b[l]) for l in self.b}
        self._t = 0  # Contatore dei timestep per Adam

    def forward(self, X):
        """Esegue il calcolo in avanti (forward pass) propagando i dati nella rete."""
        cache = {"A0": X}  # Salva l'input come attivazione iniziale A0
        A = X
        for l in range(1, self.L + 1):
            # Combinazione lineare: Z = A * W + b
            Z = A @ self.W[l] + self.b[l]
            # ReLU per gli strati nascosti, Sigmoid per lo strato di output
            A = relu(Z) if l < self.L else sigmoid(Z)
            cache[f"Z{l}"], cache[f"A{l}"] = Z, A
        return A, cache

    def compute_loss(self, y_true, y_pred, pos_weight=1.0):
        """Calcola la Binary Cross-Entropy pesata con l'aggiunta della regolarizzazione L2."""
        eps = 1e-9
        y_pred = np.clip(y_pred, eps, 1 - eps)  # Evita log(0)
        
        # Pesa diversamente i falsi negativi/positivi in caso di classi sbilanciate
        weights = np.where(y_true == 1, pos_weight, 1.0)
        bce = -np.mean(weights * (y_true * np.log(y_pred) +
                                   (1 - y_true) * np.log(1 - y_pred)))
        
        # Termine di regolarizzazione L2 (somma dei quadrati di tutti i pesi W)
        l2 = sum(np.sum(self.W[l] ** 2) for l in self.W)
        return bce + self.l2_lambda / (2 * y_true.shape[0]) * l2

    def backward(self, cache, y_true, pos_weight=1.0):
        """Esegue la propagazione all'indietro (backpropagation) calcolando i gradienti."""
        m = y_true.shape[0]
        grads_W, grads_b = {}, {}
        
        AL = np.clip(cache[f"A{self.L}"], 1e-9, 1 - 1e-9)
        weights = np.where(y_true == 1, pos_weight, 1.0)
        # Gradiente iniziale sullo strato di output
        dZ = weights * (AL - y_true) / m

        # Ciclo a ritroso dall'ultimo strato al primo
        for l in range(self.L, 0, -1):
            A_prev = cache[f"A{l - 1}"]
            # Gradiente rispetto a W (incluso il termine di derivata della regolarizzazione L2)
            grads_W[l] = A_prev.T @ dZ + (self.l2_lambda / m) * self.W[l]
            # Gradiente rispetto al bias b
            grads_b[l] = np.sum(dZ, axis=0, keepdims=True)
            
            # Calcola il gradiente per lo strato precedente (se non siamo al primo strato)
            if l > 1:
                dA_prev = dZ @ self.W[l].T
                dZ = dA_prev * relu_derivative(cache[f"Z{l - 1}"])
                
        return grads_W, grads_b

    def update_params(self, grads_W, grads_b, lr=0.001, beta1=0.9, beta2=0.999, eps=1e-8):
        """Aggiorna i parametri W e b utilizzando l'ottimizzatore Adam."""
        self._t += 1
        t = self._t
        for l in self.W:
            # Aggiornamento dei momenti per i pesi W
            self._m_W[l] = beta1 * self._m_W[l] + (1 - beta1) * grads_W[l]
            self._v_W[l] = beta2 * self._v_W[l] + (1 - beta2) * (grads_W[l] ** 2)
            
            # Correzione del bias (bias correction) per i momenti
            m_hat = self._m_W[l] / (1 - beta1 ** t)
            v_hat = self._v_W[l] / (1 - beta2 ** t)
            
            # Aggiornamento effettivo dei pesi W
            self.W[l] -= lr * m_hat / (np.sqrt(v_hat) + eps)

            # Aggiornamento dei momenti per i bias b
            self._m_b[l] = beta1 * self._m_b[l] + (1 - beta1) * grads_b[l]
            self._v_b[l] = beta2 * self._v_b[l] + (1 - beta2) * (grads_b[l] ** 2)
            
            # Correzione del bias per i bias b
            m_hat_b = self._m_b[l] / (1 - beta1 ** t)
            v_hat_b = self._v_b[l] / (1 - beta2 ** t)
            
            # Aggiornamento effettivo dei bias b
            self.b[l] -= lr * m_hat_b / (np.sqrt(v_hat_b) + eps)

    def train(self, X_train, y_train, X_val, y_val, epochs=60, batch_size=256,
              lr=0.01, pos_weight=1.0, verbose=True, seed=None):
        """
        Addestra per TUTTE le epoche richieste (nessun early stopping).
        Tiene traccia dei pesi migliori in base alla F1 di validation (Model Checkpointing).
        """
        n = X_train.shape[0]
        history = {"train_loss": [], "val_loss": [], "val_f1": []}
        best_val_f1, best_weights, best_epoch = -1.0, None, 0
        rng = np.random.default_rng(seed)

        for epoch in range(1, epochs + 1):
            t0 = time.time()
            # Mescola casualmente i dati di training a ogni epoca
            perm = rng.permutation(n)
            X_shuf, y_shuf = X_train[perm], y_train[perm]

            epoch_loss = 0.0
            n_batches = int(np.ceil(n / batch_size))
            
            # Ciclo sui mini-batch
            for bi in range(n_batches):
                s, e = bi * batch_size, min((bi + 1) * batch_size, n)
                X_batch, y_batch = X_shuf[s:e], y_shuf[s:e]
                
                y_pred, cache = self.forward(X_batch)
                epoch_loss += self.compute_loss(y_batch, y_pred, pos_weight) * (e - s)
                
                grads_W, grads_b = self.backward(cache, y_batch, pos_weight)
                self.update_params(grads_W, grads_b, lr=lr)
                
            epoch_loss /= n

            # Valutazione sul set di validazione alla fine di ogni epoca
            y_val_pred, _ = self.forward(X_val)
            val_loss = self.compute_loss(y_val, y_val_pred, pos_weight)
            _, val_f1 = find_best_threshold(y_val, y_val_pred)

            # Salvataggio delle metriche nella cronologia
            history["train_loss"].append(epoch_loss)
            history["val_loss"].append(val_loss)
            history["val_f1"].append(val_f1)

            if verbose:
                print(f"Epoca {epoch:3d}/{epochs} - loss: {epoch_loss:.4f} - "
                      f"val_loss: {val_loss:.4f} - val_F1: {val_f1:.4f} - "
                      f"({time.time() - t0:.1f}s)")

            # Model Checkpointing: memorizza i pesi se la F1 di validazione migliora
            if val_f1 > best_val_f1:
                best_val_f1 = val_f1
                best_epoch = epoch
                best_weights = ({l: self.W[l].copy() for l in self.W},
                               {l: self.b[l].copy() for l in self.b})

        if verbose:
            print(f"\nAddestramento completato ({epochs} epoche). "
                  f"Migliori pesi: epoca {best_epoch} (val_F1 = {best_val_f1:.4f}).")

        # Ripristina i pesi migliori registrati durante tutto il training
        if best_weights is not None:
            self.W, self.b = best_weights
        return history

    def predict_proba(self, X):
        """Restituisce le probabilità predette (valori continui tra 0 e 1)."""
        y_pred, _ = self.forward(X)
        return y_pred


# ============================================================================
# 4. METRICHE ( nessun sklearn.metrics)
# ============================================================================
def confusion_matrix(y_true, y_pred):
    y_true, y_pred = y_true.ravel().astype(int), y_pred.ravel().astype(int)
    
    # Calcolo dei totali per classe reale (Ground Truth)
    total_actual_pos = np.sum(y_true == 1)
    total_actual_neg = np.sum(y_true == 0)
    
    # Gestione di sicurezza per evitare divisioni per zero
    if total_actual_pos == 0 or total_actual_neg == 0:
        return 0.0, 0.0, 0.0, 0.0

    # Conteggi assoluti
    tp_count = np.sum((y_true == 1) & (y_pred == 1))
    fn_count = np.sum((y_true == 1) & (y_pred == 0))
    tn_count = np.sum((y_true == 0) & (y_pred == 0))
    fp_count = np.sum((y_true == 0) & (y_pred == 1))

    # Conversione in percentuali rispetto alla propria classe reale di appartenenza:
    # - TP e FN sono percentuali calcolate sul totale dei reali positivi (Recall / Sensibilità)
    tp = (tp_count / total_actual_pos) * 100
    fn = (fn_count / total_actual_pos) * 100

    # - TN e FP sono percentuali calcolate sul totale dei reali negativi (Specificità)
    tn = (tn_count / total_actual_neg) * 100
    fp = (fp_count / total_actual_neg) * 100

    return tp, tn, fp, fn


def precision_recall_f1(y_true, y_pred):
    tp, tn, fp, fn = confusion_matrix(y_true, y_pred)
    precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
    recall = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0.0
    accuracy = (tp + tn) / (tp + tn + fp + fn)
    return precision, recall, f1, accuracy


def macro_metrics(y_true, y_pred):
    p1, r1, f1_1, acc = precision_recall_f1(y_true, y_pred)
    p0, r0, f1_0, _ = precision_recall_f1(1 - y_true, 1 - y_pred)
    return {
        "accuracy": acc,
        "skin(1)": {"precision": p1, "recall": r1, "f1": f1_1},
        "no_skin(0)": {"precision": p0, "recall": r0, "f1": f1_0},
        "macro_precision": (p0 + p1) / 2,
        "macro_recall": (r0 + r1) / 2,
        "macro_f1": (f1_0 + f1_1) / 2,
    }


def find_best_threshold(y_true, y_proba, thresholds=None):
    if thresholds is None:
        thresholds = np.arange(0.05, 0.96, 0.01)
    best_t, best_f1 = 0.5, -1.0
    for t in thresholds:
        y_pred = (y_proba >= t).astype(float)
        _, _, f1, _ = precision_recall_f1(y_true, y_pred)
        if f1 > best_f1:
            best_f1, best_t = f1, t
    return best_t, best_f1


def print_report(title, metrics, tp, tn, fp, fn):
    print(f"\n=== {title} ===")
    print("Matrice di confusione (valori in % sulla classe reale):")
    print("            Predetto: No-Skin   Predetto: Skin")
    print(f"Reale: No-Skin        {tn:8.2f}%           {fp:8.2f}%")
    print(f"Reale: Skin           {fn:8.2f}%           {tp:8.2f}%")
    print(f"\nAccuracy:             {metrics['accuracy']:.4f}")
    print("--- Classe SKIN (1) ---")
    print(f"  Precision:         {metrics['skin(1)']['precision']:.4f}")
    print(f"  Recall:            {metrics['skin(1)']['recall']:.4f}")
    print(f"  F1-score:          {metrics['skin(1)']['f1']:.4f}")
    print("--- Classe NO-SKIN (0) ---")
    print(f"  Precision:         {metrics['no_skin(0)']['precision']:.4f}")
    print(f"  Recall:            {metrics['no_skin(0)']['recall']:.4f}")
    print(f"  F1-score:          {metrics['no_skin(0)']['f1']:.4f}")
    print("--- Media Macro ---")
    print(f"  Macro Precision:   {metrics['macro_precision']:.4f}")
    print(f"  Macro Recall:      {metrics['macro_recall']:.4f}")
    print(f"  Macro F1:          {metrics['macro_f1']:.4f}")


# ============================================================================
# 5. GRAFICI
# ============================================================================
def plot_training_curves(history):
    epochs = range(1, len(history["train_loss"]) + 1)
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.5))

    axes[0].plot(epochs, history["train_loss"], label="Train loss", color="#2b6cb0")
    axes[0].plot(epochs, history["val_loss"], label="Validation loss", color="#e53e3e")
    axes[0].set_xlabel("Epoca"); axes[0].set_ylabel("Binary Cross-Entropy (pesata)")
    axes[0].set_title("Andamento della Loss"); axes[0].legend(); axes[0].grid(alpha=0.3)

    axes[1].plot(epochs, history["val_f1"], label="Validation F1 (classe skin)", color="#38a169")
    axes[1].set_xlabel("Epoca"); axes[1].set_ylabel("F1-score")
    axes[1].set_title("F1-score sul Validation set")
    axes[1].set_ylim(min(history["val_f1"]) - 0.005, 1.001)
    axes[1].legend(); axes[1].grid(alpha=0.3)

    plt.tight_layout()
    plt.show()  # Apre la finestra con il grafico a schermo


def plot_confusion_matrix(tp, tn, fp, fn, threshold):
    matrix = np.array([[tn, fp], [fn, tp]])
    labels = ["No-Skin (0)", "Skin (1)"]

    fig, ax = plt.subplots(figsize=(5.5, 5))
    im = ax.imshow(matrix, cmap="Blues")
    ax.set_xticks([0, 1]); ax.set_xticklabels(labels)
    ax.set_yticks([0, 1]); ax.set_yticklabels(labels)
    ax.set_xlabel("Classe Predetta"); ax.set_ylabel("Classe Reale")
    ax.set_title(f"Matrice di Confusione - Test Set\n(soglia = {threshold:.2f})")

    for i in range(2):
        for j in range(2):
            val = matrix[i, j]
            color = "white" if val > matrix.max() / 2 else "black"
            ax.text(j, i, f"{val:.2f}%", ha="center", va="center", color=color, fontsize=13)

    plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    plt.tight_layout()
    plt.show()  # Apre la finestra con la matrice di confusione a schermo


# ============================================================================
# 6. MAIN — ESEGUE TUTTA LA PIPELINE IN UN UNICO LANCIO
# ============================================================================
def main():
    print("=" * 60)
    print("PIPELINE COMPLETA - CLASSIFICAZIONE SKIN / NO-SKIN")
    print("=" * 60)

    # --- 1. Caricamento dati ---
    print("\n[1/6] Caricamento dataset...")
    # Caricamento dei file nei rispettivi set di training, validation e test
    X_train, y_train = load_libsvm_dataset("training_set.txt")
    X_val, y_val = load_libsvm_dataset("validation_set.txt")
    X_test, y_test = load_libsvm_dataset("test_set.txt")
    
    print(f"    Training set:   {X_train.shape[0]} campioni")
    print(f"    Validation set: {X_val.shape[0]} campioni")
    print(f"    Test set:       {X_test.shape[0]} campioni")
    # Mostra la proporzione di pixel di pelle (classe 1) nel training set
    print(f"    Percentuale skin nel training: {100 * y_train.mean():.2f}%")

    # --- 2. Standardizzazione ---
    print("\n[2/6] Standardizzazione...")
    scaler = StandardScaler()
    # Adatta lo scaler sul training e trasforma sia train che validation
    X_train = scaler.fit_transform(X_train)
    X_val = scaler.transform(X_val)
    X_test_scaled = scaler.transform(X_test)

    # Calcolo del peso per gestire il forte sbilanciamento tra classi (es. meno pixel skin)
    n_pos, n_neg = np.sum(y_train == 1), np.sum(y_train == 0)
    pos_weight = n_neg / n_pos
    print(f"    Pos weight (bilanciamento classi) nella loss: {pos_weight:.3f}")

    # --- 3. Costruzione e addestramento rete ---
    print("\n[3/6] Addestramento rete neurale (3 -> 16 -> 8 -> 1)...")
    # Inizializzazione della rete con 3 input, due hidden layer (16 e 8 neuroni) e regolarizzazione L2
    nn = NeuralNetwork(layer_sizes=[3, 16, 8, 1], l2_lambda=1e-4, seed=RNG_SEED)
    # Avvio del processo di training per 60 epoche con mini-batch da 256
    history = nn.train(X_train, y_train, X_val, y_val, epochs=60, batch_size=256,
                       lr=0.01, pos_weight=pos_weight, verbose=True, seed=RNG_SEED)

    # --- 4. Tuning soglia su validation set ---
    print("\n[4/6] Ottimizzazione soglia di decisione...")
    y_val_proba = nn.predict_proba(X_val)
    # Ricerca della soglia ideale sul validation set per massimizzare la metrica F1
    best_threshold, best_val_f1 = find_best_threshold(y_val, y_val_proba)
    print(f"    Soglia ottimale: {best_threshold:.2f} (F1 validation: {best_val_f1:.4f})")

    # --- 5. Valutazione finale sul test set ---
    print("\n[5/6] Valutazione sul test set...")
    y_test_proba = nn.predict_proba(X_test_scaled)
    
    # Valutazione: Utilizzando la soglia ottimizzata trovata sul validation set
    y_test_pred = (y_test_proba >= best_threshold).astype(float)
    tp, tn, fp, fn = confusion_matrix(y_test, y_test_pred)
    metrics = macro_metrics(y_test, y_test_pred)
    print_report("RISULTATI SUL TEST SET (soglia ottimizzata)", metrics, tp, tn, fp, fn)

    # --- 6. Grafici a schermo (senza salvataggio su file) ---
    print("\n[6/6] Visualizzazione grafici a schermo...")
    plot_training_curves(history)
    plot_confusion_matrix(tp, tn, fp, fn, best_threshold)

    return nn, history


if __name__ == "__main__":
    main()